Abgabegruppe: Philipp Barth (2765590), Christian Idelberger(2776106), Pascal Schmitt (2776693)
Der Code wurde mit Julia (Version "1.11.5", in VS Code) geschrieben.
B1A3a = Blatt 1, Aufgabe 3a,
...