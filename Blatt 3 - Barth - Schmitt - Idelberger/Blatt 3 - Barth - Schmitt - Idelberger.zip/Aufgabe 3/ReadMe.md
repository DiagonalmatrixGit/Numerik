Abgabegruppe: Philipp Barth (2765590), Christian Idelberger(2776106), Pascal Schmitt (2776693)
Abgabe erstellt mit Julia 1.11.5

Aufgabe 4 wurde nicht bearbeitet.
